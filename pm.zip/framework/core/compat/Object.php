<?php

abstract class Object extends SS_Object
{
}